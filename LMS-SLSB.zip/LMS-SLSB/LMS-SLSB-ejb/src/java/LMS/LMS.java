/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LMS;

import javax.ejb.Stateless;

/**
 *
 * @author chira
 */
@Stateless
public class LMS implements LMSLocal {

    
    String bks[]={"JAVA","DS","AIT","SE"};
	int quantity[]={10,10,10,10};
	
	
	@Override
	public String issueBook(String bookName,int amount)
	{
		int i,flag=0;
		for(i=0;i<bks.length;i++)
		{
			if(bookName.equalsIgnoreCase(bks[i]))
			{
				flag=1;
				break;
			}
		}
			if(flag==1)
			{
				if(quantity[i]==0)
				{
					return "Books not available in Book "+bks[i];	
				}
				else
				{
					quantity[i]=quantity[i]-amount;
					return "Success!!";
				}
			}
		else
		return "Incorrect Account Name";
	}
 @Override
	public String returnBook(String bookName,int amount)
	{
		int i,flag=0;
		for(i=0;i<bks.length;i++)
		{
		if(bookName.equalsIgnoreCase(bks[i]))
			{
				flag=1;
				break;
			}
			}
			if(flag==1)
			{
				if(quantity[i]==10)
				{
					return "Book Already Returned";
				}
				else
				{
				quantity[i]=quantity[i]+amount;
				return "Success!!";
				}
			}
		else
		return "Incorrect Account Name";
	}

 
	
	 @Override
	public String displayBook(int i)
	{
		return (bks[i]+"\t"+quantity[i]);
	}

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
}
